"use client"

import { useState, useRef, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Upload, ImageIcon, FileText, Check, Loader2, AlertCircle, Trash2, Sparkles } from "lucide-react"
import Image from "next/image"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export function ImageUploader({ onImageProcessed }) {
  const [isDragging, setIsDragging] = useState(false)
  const [uploadedImage, setUploadedImage] = useState(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [isProcessed, setIsProcessed] = useState(false)
  const [processingProgress, setProcessingProgress] = useState(0)
  const [processingStage, setProcessingStage] = useState("")
  const [error, setError] = useState(null)
  const [imageQuality, setImageQuality] = useState(null)
  const [aiEnhanced, setAiEnhanced] = useState(true)
  const fileInputRef = useRef(null)

  const handleDragOver = (e) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const handleDrop = (e) => {
    e.preventDefault()
    setIsDragging(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0])
    }
  }

  const handleFileInput = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0])
    }
  }

  const handleFile = (file) => {
    // Reset states
    setError(null)
    setIsProcessed(false)
    setProcessingProgress(0)

    // Validate file type
    if (!file.type.startsWith("image/") && file.type !== "application/pdf") {
      setError("Please upload an image or PDF file")
      return
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      setError("File size exceeds 10MB limit")
      return
    }

    if (file.type.startsWith("image/")) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setUploadedImage(e.target.result)
        // Simulate image quality assessment
        assessImageQuality(e.target.result)
      }
      reader.readAsDataURL(file)
    } else if (file.type === "application/pdf") {
      // For PDF, we'd use a PDF renderer in a real app
      // Here we'll just set a placeholder
      setUploadedImage("/placeholder.svg?height=400&width=300")
      setImageQuality("good")
    }
  }

  const assessImageQuality = (imageData) => {
    // In a real app, we would analyze the image for:
    // - Resolution
    // - Brightness/contrast
    // - Blur detection
    // - Text clarity

    // Simulate quality assessment
    setTimeout(() => {
      // Randomly assign quality for demo purposes
      const qualities = ["excellent", "good", "fair", "poor"]
      const randomQuality = qualities[Math.floor(Math.random() * 3)] // Bias toward better quality
      setImageQuality(randomQuality)
    }, 500)
  }

  const processImage = useCallback(async () => {
    setIsProcessing(true)
    setProcessingProgress(0)
    setProcessingStage("Initializing...")

    // Simulate OCR processing with progress updates
    const stages = [
      { stage: "Analyzing image quality...", progress: 5 },
      { stage: "Detecting document boundaries...", progress: 10 },
      { stage: "Performing OCR text extraction...", progress: 25 },
      { stage: "Identifying key fields...", progress: 40 },
      { stage: "Categorizing transaction data...", progress: 55 },
      { stage: "Validating extracted information...", progress: 70 },
      { stage: aiEnhanced ? "Applying AI enhancement..." : "Skipping AI enhancement...", progress: 85 },
      { stage: "Generating accounting entries...", progress: 95 },
      { stage: "Finalizing...", progress: 98 },
    ]

    let currentStage = 0

    const processInterval = setInterval(() => {
      if (currentStage < stages.length) {
        setProcessingStage(stages[currentStage].stage)
        setProcessingProgress(stages[currentStage].progress)
        currentStage++
      } else {
        clearInterval(processInterval)
        setProcessingProgress(100)
        setProcessingStage("Processing complete!")

        // Generate sample data based on image quality
        generateExtractedData(imageQuality)
      }
    }, 600)

    return () => clearInterval(processInterval)
  }, [imageQuality, aiEnhanced])

  const generateExtractedData = async (quality) => {
    // Base data
    const baseData = {
      date: new Date().toISOString().split("T")[0],
      vendor: "Office Supplies Co.",
      amount: 125.75,
      description: "Office supplies and stationery",
      category: "Office Expenses",
      taxAmount: 10.06,
      receiptNumber: "R-12345",
      paymentMethod: "Credit Card",
      currency: "USD",
    }

    // Add more detailed data based on image quality
    let extractedData

    switch (quality) {
      case "excellent":
        extractedData = {
          ...baseData,
          lineItems: [
            { description: "Premium Paper Ream", quantity: 2, unitPrice: 24.99, amount: 49.98 },
            { description: "Gel Pens (Pack of 12)", quantity: 3, unitPrice: 12.99, amount: 38.97 },
            { description: "Desk Organizer", quantity: 1, unitPrice: 36.8, amount: 36.8 },
          ],
          taxRate: 0.08,
          taxAmount: 10.06,
          subtotal: 125.75,
          total: 135.81,
          contactInfo: {
            address: "123 Business St, Suite 101",
            phone: "(555) 123-4567",
            email: "sales@officesupplies.co",
          },
          confidence: 0.95,
        }
        break
      case "good":
        extractedData = {
          ...baseData,
          lineItems: [
            { description: "Paper Supplies", quantity: 2, unitPrice: 24.99, amount: 49.98 },
            { description: "Pens", quantity: 3, unitPrice: 12.99, amount: 38.97 },
            { description: "Desk Items", quantity: 1, unitPrice: 36.8, amount: 36.8 },
          ],
          taxRate: 0.08,
          subtotal: 125.75,
          total: 135.81,
          confidence: 0.85,
        }
        break
      case "fair":
        extractedData = {
          ...baseData,
          lineItems: [
            { description: "Office Supplies", quantity: null, unitPrice: null, amount: 49.98 },
            { description: "Stationery", quantity: null, unitPrice: null, amount: 75.77 },
          ],
          subtotal: 125.75,
          total: 135.81,
          confidence: 0.7,
        }
        break
      case "poor":
      default:
        extractedData = {
          ...baseData,
          confidence: 0.5,
        }
    }

    // If AI enhancement is enabled, improve the data
    if (aiEnhanced) {
      try {
        // In a real implementation, we would send the actual OCR results to the AI
        // For this demo, we'll simulate AI enhancement by improving the data

        // Simulate AI processing delay
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Enhance the data based on quality
        if (quality === "poor" || quality === "fair") {
          // For poor/fair quality, AI significantly improves the data
          extractedData = {
            ...extractedData,
            confidence: extractedData.confidence + 0.2,
            category: "Office Supplies & Equipment",
            description: "Office supplies including paper, pens, and desk organizer",
            lineItems: extractedData.lineItems || [
              { description: "Premium Paper Ream", quantity: 2, unitPrice: 24.99, amount: 49.98 },
              { description: "Gel Pens (Pack of 12)", quantity: 3, unitPrice: 12.99, amount: 38.97 },
              { description: "Desk Organizer", quantity: 1, unitPrice: 36.8, amount: 36.8 },
            ],
            accountingRecommendation:
              "Categorize as Office Supplies expense. If items include equipment with useful life > 1 year, consider capitalizing as Fixed Assets.",
          }
        } else {
          // For good/excellent quality, AI adds accounting context
          extractedData = {
            ...extractedData,
            confidence: Math.min(0.98, extractedData.confidence + 0.05),
            accountingRecommendation:
              "Standard office supplies expense. Debit Office Supplies, Credit Accounts Payable or Cash.",
          }
        }

        // Add AI-specific fields
        extractedData.aiEnhanced = true
        extractedData.aiSuggestions = [
          "Based on the vendor and items, this should be categorized as 'Office Supplies' expense",
          "The tax rate of 8% suggests this purchase was made in a state with that standard rate",
          "Consider setting up a recurring monthly budget for office supplies based on this spending pattern",
        ]
      } catch (error) {
        console.error("Error enhancing data with AI:", error)
        // If AI enhancement fails, we still have the base extracted data
        extractedData.aiEnhanced = false
      }
    }

    // Complete processing
    setIsProcessing(false)
    setIsProcessed(true)

    // After a short delay, trigger the callback with the processed data
    setTimeout(() => {
      onImageProcessed(extractedData)
    }, 500)
  }

  const triggerFileInput = () => {
    fileInputRef.current.click()
  }

  const resetUpload = () => {
    setUploadedImage(null)
    setIsProcessed(false)
    setIsProcessing(false)
    setProcessingProgress(0)
    setError(null)
    setImageQuality(null)
  }

  const getQualityColor = (quality) => {
    switch (quality) {
      case "excellent":
        return "text-green-500"
      case "good":
        return "text-emerald-500"
      case "fair":
        return "text-amber-500"
      case "poor":
        return "text-red-500"
      default:
        return "text-muted-foreground"
    }
  }

  const getQualityMessage = (quality) => {
    switch (quality) {
      case "excellent":
        return "High-quality image. Excellent for accurate data extraction."
      case "good":
        return "Good image quality. Should provide reliable data extraction."
      case "fair":
        return "Fair image quality. Some details may not be accurately extracted."
      case "poor":
        return "Poor image quality. Data extraction may be limited or inaccurate."
      default:
        return "Analyzing image quality..."
    }
  }

  const toggleAiEnhancement = () => {
    setAiEnhanced(!aiEnhanced)
  }

  return (
    <div className="space-y-4">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileInput}
        accept="image/*,application/pdf"
        className="hidden"
      />

      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {!uploadedImage ? (
        <Card
          className={`flex flex-col items-center justify-center p-12 border-2 border-dashed ${
            isDragging ? "border-primary bg-primary/5" : "border-muted-foreground/25"
          } rounded-lg cursor-pointer transition-colors`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={triggerFileInput}
        >
          <Upload className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">Drag and drop your document</h3>
          <p className="text-sm text-muted-foreground mb-4 text-center">
            Upload a receipt, invoice, or any financial document
            <br />
            Supports JPG, PNG, and PDF files up to 10MB
          </p>
          <Button type="button" variant="secondary">
            <Upload className="mr-2 h-4 w-4" /> Browse Files
          </Button>
        </Card>
      ) : (
        <div className="space-y-4">
          <div className="relative aspect-[4/3] w-full overflow-hidden rounded-lg border">
            <Image src={uploadedImage || "/placeholder.svg"} alt="Uploaded document" fill className="object-contain" />

            {imageQuality && !isProcessing && !isProcessed && (
              <div className="absolute bottom-0 left-0 right-0 bg-background/80 backdrop-blur-sm p-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={`font-medium ${getQualityColor(imageQuality)}`}>
                      {imageQuality.charAt(0).toUpperCase() + imageQuality.slice(1)} Quality
                    </span>
                  </div>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-6 w-6">
                          <AlertCircle className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="max-w-xs">{getQualityMessage(imageQuality)}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </div>
            )}
          </div>

          {isProcessing && (
            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span>{processingStage}</span>
                <span>{processingProgress}%</span>
              </div>
              <Progress value={processingProgress} className="h-2" />
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-2 justify-between items-center">
            <div className="flex items-center gap-2">
              <ImageIcon className="h-5 w-5 text-muted-foreground" />
              <span className="text-sm">
                {isProcessed ? "Document processed successfully" : "Document uploaded successfully"}
              </span>
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={toggleAiEnhancement}
                className={aiEnhanced ? "border-primary text-primary" : ""}
                disabled={isProcessing || isProcessed}
              >
                <Sparkles className="mr-2 h-4 w-4" />
                {aiEnhanced ? "AI Enhanced" : "Enable AI"}
              </Button>

              <Button variant="outline" size="sm" onClick={resetUpload}>
                <Trash2 className="mr-2 h-4 w-4" />
                Remove
              </Button>

              <Button onClick={processImage} disabled={isProcessing || isProcessed} size="sm">
                {isProcessing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : isProcessed ? (
                  <>
                    <Check className="mr-2 h-4 w-4" />
                    Processed
                  </>
                ) : (
                  <>
                    <FileText className="mr-2 h-4 w-4" />
                    Extract Data
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

