"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Check, Edit, Save, X, Plus, Trash, AlertCircle, HelpCircle, Download, Sparkles } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function JournalEntries({ data, onAiAssistClick }) {
  const [isEditing, setIsEditing] = useState(false)
  const [entries, setEntries] = useState([])
  const [activeTab, setActiveTab] = useState("journal")
  const [showAiAssistant, setShowAiAssistant] = useState(false)

  // If no data is provided, show a placeholder message
  if (!data) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <FileIcon className="h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-medium mb-2">No Journal Entries Yet</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Upload a document to automatically generate journal entries
        </p>
      </div>
    )
  }

  // Generate journal entries based on the data
  const generateEntries = () => {
    // Basic entries (always present)
    const basicEntries = [
      {
        id: 1,
        account: "Office Expenses",
        accountType: "expense",
        description: data.description,
        debit: data.amount,
        credit: 0,
        confidence: data.confidence || 0.85,
        aiSuggested: data.aiEnhanced || false,
      },
      {
        id: 2,
        account: "Accounts Payable",
        accountType: "liability",
        description: `Payment to ${data.vendor}`,
        debit: 0,
        credit: data.amount,
        confidence: data.confidence || 0.85,
        aiSuggested: data.aiEnhanced || false,
      },
    ]

    // Add tax entry if we have detailed data
    const taxEntries =
      data.taxAmount && data.taxAmount > 0
        ? [
            {
              id: 3,
              account: "Sales Tax Payable",
              accountType: "liability",
              description: `Tax on ${data.vendor} purchase`,
              debit: 0,
              credit: data.taxAmount,
              confidence: (data.confidence || 0.85) - 0.05, // Slightly lower confidence for tax
              aiSuggested: data.aiEnhanced || false,
            },
            {
              id: 4,
              account: "Office Expenses",
              accountType: "expense",
              description: `Tax on ${data.description}`,
              debit: data.taxAmount,
              credit: 0,
              confidence: (data.confidence || 0.85) - 0.05,
              aiSuggested: data.aiEnhanced || false,
            },
          ]
        : []

    // If we have AI suggestions, potentially add more sophisticated entries
    const aiEntries =
      data.aiEnhanced && data.accountingRecommendation
        ? [
            // AI might suggest a more specific account classification
            {
              id: 5,
              account: "Office Supplies", // More specific than general "Office Expenses"
              accountType: "expense",
              description: "Reclassified from Office Expenses for better tracking",
              debit: data.amount,
              credit: 0,
              confidence: 0.92,
              aiSuggested: true,
              isRecommendation: true,
            },
            {
              id: 6,
              account: "Office Expenses",
              accountType: "expense",
              description: "Reclassification to Office Supplies",
              debit: 0,
              credit: data.amount,
              confidence: 0.92,
              aiSuggested: true,
              isRecommendation: true,
            },
          ]
        : []

    return [...basicEntries, ...taxEntries, ...aiEntries]
  }

  // Initialize entries if not already set
  if (entries.length === 0 && data) {
    setEntries(generateEntries())
  }

  const toggleEditing = () => {
    setIsEditing(!isEditing)
  }

  const addNewEntry = () => {
    const newEntry = {
      id: entries.length + 1,
      account: "",
      accountType: "expense",
      description: "",
      debit: 0,
      credit: 0,
      confidence: 1.0, // User-added entries have 100% confidence
      isNew: true,
    }

    setEntries([...entries, newEntry])
  }

  const removeEntry = (id) => {
    setEntries(entries.filter((entry) => entry.id !== id))
  }

  const updateEntry = (id, field, value) => {
    setEntries(
      entries.map((entry) => {
        if (entry.id === id) {
          return { ...entry, [field]: value }
        }
        return entry
      }),
    )
  }

  const saveChanges = () => {
    // In a real app, we would save to a database here
    setIsEditing(false)
  }

  const getConfidenceColor = (confidence) => {
    if (confidence >= 0.9) return "bg-green-500/10 text-green-500 hover:bg-green-500/20"
    if (confidence >= 0.7) return "bg-amber-500/10 text-amber-500 hover:bg-amber-500/20"
    return "bg-red-500/10 text-red-500 hover:bg-red-500/20"
  }

  const getConfidenceLabel = (confidence) => {
    if (confidence >= 0.9) return "High"
    if (confidence >= 0.7) return "Medium"
    return "Low"
  }

  // Calculate totals
  const totalDebit = entries
    .filter((e) => !e.isRecommendation)
    .reduce((sum, entry) => sum + (Number.parseFloat(entry.debit) || 0), 0)
  const totalCredit = entries
    .filter((e) => !e.isRecommendation)
    .reduce((sum, entry) => sum + (Number.parseFloat(entry.credit) || 0), 0)
  const isBalanced = totalDebit.toFixed(2) === totalCredit.toFixed(2)

  // Add a new function for exporting entries
  const exportEntries = () => {
    // Format entries for export
    const formattedEntries = entries
      .filter((entry) => !entry.isRecommendation)
      .map((entry) => {
        return {
          date: data.date || new Date().toISOString().split("T")[0],
          accountTitle: entry.account,
          debit: entry.debit > 0 ? Number.parseFloat(entry.debit).toFixed(2) : "",
          credit: entry.credit > 0 ? Number.parseFloat(entry.credit).toFixed(2) : "",
          narration: entry.description,
        }
      })

    // Create CSV content
    let csvContent = "Date,Account Title,Debit (₹),Credit (₹),Narration\n"
    formattedEntries.forEach((entry) => {
      csvContent += `${entry.date},${entry.accountTitle},${entry.debit},${entry.credit},"${entry.narration}"\n`
    })

    // Add narration at the end
    csvContent += `\nNarration: "${data.description || "Being the transaction recorded in the business."}"\n`

    // Create and download the file
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", `journal_entry_${data.receiptNumber || "JE001"}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <div className="space-y-4">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="flex justify-between items-center mb-4">
          <TabsList>
            <TabsTrigger value="journal">Journal Entry</TabsTrigger>
            <TabsTrigger value="details">Document Details</TabsTrigger>
          </TabsList>

          <div className="flex gap-2">
            {activeTab === "journal" && (
              <>
                <Button variant="outline" size="sm" onClick={toggleEditing}>
                  {isEditing ? (
                    <>
                      <X className="mr-2 h-4 w-4" />
                      Cancel
                    </>
                  ) : (
                    <>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit
                    </>
                  )}
                </Button>

                <Button variant="outline" size="sm" onClick={exportEntries}>
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </>
            )}

            <Button size="sm" onClick={onAiAssistClick || (() => setShowAiAssistant(true))}>
              <Sparkles className="mr-2 h-4 w-4" />
              AI Assist
            </Button>
          </div>
        </div>

        <TabsContent value="journal" className="space-y-4 mt-0">
          <Card>
            <CardContent className="p-4">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="text-lg font-medium">Journal Entry #{data.receiptNumber || "JE-001"}</h3>
                  <p className="text-sm text-muted-foreground">
                    {data.date} • {data.vendor}
                  </p>
                </div>

                {!isBalanced && (
                  <Alert variant="destructive" className="max-w-xs p-2">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription className="text-xs">
                      Entry is not balanced. Debits must equal credits.
                    </AlertDescription>
                  </Alert>
                )}
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[30%]">Account</TableHead>
                    <TableHead className="w-[30%]">Description</TableHead>
                    <TableHead className="text-right">Debit</TableHead>
                    <TableHead className="text-right">Credit</TableHead>
                    {isEditing && <TableHead className="w-[50px]"></TableHead>}
                    {!isEditing && <TableHead className="w-[80px]">Confidence</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {entries
                    .filter((entry) => !entry.isRecommendation)
                    .map((entry) => (
                      <TableRow key={entry.id}>
                        <TableCell>
                          {isEditing ? (
                            <Select
                              defaultValue={entry.account || ""}
                              onValueChange={(value) => updateEntry(entry.id, "account", value)}
                            >
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="Select account" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Cash">Cash</SelectItem>
                                <SelectItem value="Accounts Receivable">Accounts Receivable</SelectItem>
                                <SelectItem value="Accounts Payable">Accounts Payable</SelectItem>
                                <SelectItem value="Office Expenses">Office Expenses</SelectItem>
                                <SelectItem value="Office Supplies">Office Supplies</SelectItem>
                                <SelectItem value="Utilities">Utilities</SelectItem>
                                <SelectItem value="Rent Expense">Rent Expense</SelectItem>
                                <SelectItem value="Sales Tax Payable">Sales Tax Payable</SelectItem>
                                <SelectItem value="Prepaid Expenses">Prepaid Expenses</SelectItem>
                              </SelectContent>
                            </Select>
                          ) : (
                            <div className="flex items-center gap-2">
                              <span>{entry.account}</span>
                              {entry.isNew && (
                                <Badge variant="outline" className="text-xs">
                                  New
                                </Badge>
                              )}
                              {entry.aiSuggested && (
                                <Badge variant="outline" className="text-xs bg-primary/10 text-primary">
                                  AI
                                </Badge>
                              )}
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          {isEditing ? (
                            <Input
                              defaultValue={entry.description || ""}
                              onChange={(e) => updateEntry(entry.id, "description", e.target.value)}
                            />
                          ) : (
                            entry.description
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {isEditing ? (
                            <Input
                              type="number"
                              step="0.01"
                              min="0"
                              defaultValue={entry.debit || ""}
                              className="text-right"
                              onChange={(e) => updateEntry(entry.id, "debit", Number.parseFloat(e.target.value) || 0)}
                            />
                          ) : entry.debit ? (
                            `$${Number.parseFloat(entry.debit).toFixed(2)}`
                          ) : (
                            "-"
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {isEditing ? (
                            <Input
                              type="number"
                              step="0.01"
                              min="0"
                              defaultValue={entry.credit || ""}
                              className="text-right"
                              onChange={(e) => updateEntry(entry.id, "credit", Number.parseFloat(e.target.value) || 0)}
                            />
                          ) : entry.credit ? (
                            `$${Number.parseFloat(entry.credit).toFixed(2)}`
                          ) : (
                            "-"
                          )}
                        </TableCell>
                        {isEditing ? (
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => removeEntry(entry.id)}
                              className="h-8 w-8"
                            >
                              <Trash className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        ) : (
                          <TableCell>
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Badge variant="outline" className={`${getConfidenceColor(entry.confidence)}`}>
                                    {getConfidenceLabel(entry.confidence)}
                                  </Badge>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>AI confidence: {Math.round(entry.confidence * 100)}%</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </TableCell>
                        )}
                      </TableRow>
                    ))}

                  {isEditing && (
                    <TableRow>
                      <TableCell colSpan={5}>
                        <Button variant="outline" size="sm" className="w-full" onClick={addNewEntry}>
                          <Plus className="h-4 w-4 mr-2" />
                          Add Account
                        </Button>
                      </TableCell>
                    </TableRow>
                  )}

                  <TableRow className="font-medium border-t-2">
                    <TableCell colSpan={2}>Total</TableCell>
                    <TableCell className="text-right">${totalDebit.toFixed(2)}</TableCell>
                    <TableCell className="text-right">${totalCredit.toFixed(2)}</TableCell>
                    <TableCell></TableCell>
                  </TableRow>
                </TableBody>
              </Table>

              {data.aiEnhanced && entries.some((e) => e.isRecommendation) && (
                <div className="mt-6 border rounded-lg p-4 bg-primary/5">
                  <div className="flex items-center gap-2 mb-3">
                    <Sparkles className="h-4 w-4 text-primary" />
                    <h4 className="font-medium">AI Recommendations</h4>
                  </div>

                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[30%]">Account</TableHead>
                        <TableHead className="w-[30%]">Description</TableHead>
                        <TableHead className="text-right">Debit</TableHead>
                        <TableHead className="text-right">Credit</TableHead>
                        <TableHead className="w-[80px]">Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {entries
                        .filter((entry) => entry.isRecommendation)
                        .map((entry) => (
                          <TableRow key={entry.id}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <span>{entry.account}</span>
                                <Badge variant="outline" className="text-xs bg-primary/10 text-primary">
                                  AI
                                </Badge>
                              </div>
                            </TableCell>
                            <TableCell>{entry.description}</TableCell>
                            <TableCell className="text-right">
                              {entry.debit ? `$${Number.parseFloat(entry.debit).toFixed(2)}` : "-"}
                            </TableCell>
                            <TableCell className="text-right">
                              {entry.credit ? `$${Number.parseFloat(entry.credit).toFixed(2)}` : "-"}
                            </TableCell>
                            <TableCell>
                              <Button variant="outline" size="sm" className="h-7 w-full">
                                Apply
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>

                  <div className="mt-3 text-sm text-muted-foreground">
                    <p>The AI suggests reclassifying this transaction for more accurate financial reporting.</p>
                  </div>
                </div>
              )}

              <div className="flex items-center gap-2 mt-4 text-sm text-muted-foreground">
                <HelpCircle className="h-4 w-4" />
                <span>Confidence indicators show the AI's certainty in the extracted data.</span>
              </div>
            </CardContent>
          </Card>

          {isEditing && (
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={toggleEditing}>
                Cancel
              </Button>
              <Button onClick={saveChanges} disabled={!isBalanced}>
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="details" className="space-y-4 mt-0">
          <Card>
            <CardContent className="p-4">
              <h3 className="text-lg font-medium mb-4">Document Details</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-2">Basic Information</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="font-medium">Vendor:</div>
                      <div>{data.vendor}</div>

                      <div className="font-medium">Date:</div>
                      <div>{data.date}</div>

                      <div className="font-medium">Receipt Number:</div>
                      <div>{data.receiptNumber || "N/A"}</div>

                      <div className="font-medium">Payment Method:</div>
                      <div>{data.paymentMethod || "N/A"}</div>

                      <div className="font-medium">Currency:</div>
                      <div>{data.currency || "USD"}</div>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-2">Amounts</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="font-medium">Subtotal:</div>
                      <div>${data.subtotal?.toFixed(2) || data.amount.toFixed(2)}</div>

                      <div className="font-medium">Tax Amount:</div>
                      <div>${data.taxAmount?.toFixed(2) || "0.00"}</div>

                      <div className="font-medium">Tax Rate:</div>
                      <div>{data.taxRate ? `${(data.taxRate * 100).toFixed(2)}%` : "N/A"}</div>

                      <div className="font-medium">Total:</div>
                      <div>${data.total?.toFixed(2) || data.amount.toFixed(2)}</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-2">Line Items</h4>
                    {data.lineItems ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Description</TableHead>
                            <TableHead className="text-right">Qty</TableHead>
                            <TableHead className="text-right">Price</TableHead>
                            <TableHead className="text-right">Amount</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {data.lineItems.map((item, index) => (
                            <TableRow key={index}>
                              <TableCell>{item.description}</TableCell>
                              <TableCell className="text-right">{item.quantity || "-"}</TableCell>
                              <TableCell className="text-right">
                                {item.unitPrice ? `$${item.unitPrice.toFixed(2)}` : "-"}
                              </TableCell>
                              <TableCell className="text-right">${item.amount.toFixed(2)}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    ) : (
                      <div className="text-sm text-muted-foreground">No line items detected</div>
                    )}
                  </div>

                  {data.contactInfo && (
                    <div>
                      <h4 className="text-sm font-medium text-muted-foreground mb-2">Vendor Contact</h4>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div className="font-medium">Address:</div>
                        <div>{data.contactInfo.address || "N/A"}</div>

                        <div className="font-medium">Phone:</div>
                        <div>{data.contactInfo.phone || "N/A"}</div>

                        <div className="font-medium">Email:</div>
                        <div>{data.contactInfo.email || "N/A"}</div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {data.aiEnhanced && data.aiSuggestions && (
                <div className="mt-6 pt-4 border-t">
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="h-4 w-4 text-primary" />
                    <h4 className="text-sm font-medium">AI Insights</h4>
                  </div>
                  <ul className="space-y-2 text-sm">
                    {data.aiSuggestions.map((suggestion, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="text-primary mt-1">•</span>
                        <span>{suggestion}</span>
                      </li>
                    ))}
                  </ul>

                  {data.accountingRecommendation && (
                    <div className="mt-3 p-3 bg-muted/50 rounded-lg">
                      <div className="font-medium mb-1">Accounting Recommendation:</div>
                      <p className="text-sm">{data.accountingRecommendation}</p>
                    </div>
                  )}
                </div>
              )}

              <div className="mt-6 pt-4 border-t">
                <h4 className="text-sm font-medium text-muted-foreground mb-2">Notes</h4>
                <div className="text-sm">
                  {data.confidence >= 0.9 ? (
                    <div className="flex items-center gap-2 text-green-600">
                      <Check className="h-4 w-4" />
                      High confidence extraction. All data appears accurate.
                    </div>
                  ) : data.confidence >= 0.7 ? (
                    <div className="flex items-center gap-2 text-amber-600">
                      <AlertCircle className="h-4 w-4" />
                      Medium confidence extraction. Please verify key details.
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-red-600">
                      <AlertCircle className="h-4 w-4" />
                      Low confidence extraction. Manual verification recommended.
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function FileIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
      <polyline points="14 2 14 8 20 8" />
    </svg>
  )
}

