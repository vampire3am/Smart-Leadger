"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Loader2, Sparkles, Copy, Download, AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

type JournalEntry = {
  date: string
  accountTitle: string
  debit: number | null
  credit: number | null
  narration?: string
}

export function PromptEntryGenerator() {
  const [prompt, setPrompt] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [entries, setEntries] = useState<JournalEntry[]>([])
  const [narration, setNarration] = useState("")
  const [error, setError] = useState<string | null>(null)

  const handleGenerateEntries = async () => {
    if (!prompt.trim()) return

    setIsLoading(true)
    setError(null)

    try {
      // Simulate AI processing with a delay
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Generate entries based on the prompt
      const generatedEntries = generateEntriesFromPrompt(prompt)
      setEntries(generatedEntries.entries)
      setNarration(generatedEntries.narration)
    } catch (err) {
      setError("Failed to generate entries. Please try a different prompt.")
      console.error("Error generating entries:", err)
    } finally {
      setIsLoading(false)
    }
  }

  const generateEntriesFromPrompt = (promptText: string) => {
    // This is a simplified rule-based system to generate entries
    // In a real app, this would be handled by an AI model

    const lowerPrompt = promptText.toLowerCase()
    let entries: JournalEntry[] = []
    let narration = ""

    // Check for common accounting scenarios
    if (lowerPrompt.includes("start") && lowerPrompt.includes("business") && lowerPrompt.includes("cash")) {
      // Extract amount using regex
      const amountMatch = promptText.match(/(\d+,)*\d+/)
      const amount = amountMatch ? amountMatch[0].replace(/,/g, "") : "200000"

      // Format with commas for display
      const formattedAmount = Number.parseInt(amount).toLocaleString("en-IN")

      entries = [
        {
          date: new Date().toISOString().split("T")[0],
          accountTitle: "Cash A/c",
          debit: Number.parseInt(amount),
          credit: null,
        },
        {
          date: new Date().toISOString().split("T")[0],
          accountTitle: "Capital A/c",
          debit: null,
          credit: Number.parseInt(amount),
        },
      ]

      narration = "Being the capital introduced by the owner in the business."
    } else if (lowerPrompt.includes("purchase") && (lowerPrompt.includes("cash") || lowerPrompt.includes("paid"))) {
      // Extract amount using regex
      const amountMatch = promptText.match(/(\d+,)*\d+/)
      const amount = amountMatch ? amountMatch[0].replace(/,/g, "") : "50000"

      // Extract item being purchased
      let item = "goods"
      if (lowerPrompt.includes("furniture")) item = "furniture"
      else if (lowerPrompt.includes("equipment")) item = "equipment"
      else if (lowerPrompt.includes("inventory")) item = "inventory"

      entries = [
        {
          date: new Date().toISOString().split("T")[0],
          accountTitle: `${item.charAt(0).toUpperCase() + item.slice(1)} A/c`,
          debit: Number.parseInt(amount),
          credit: null,
        },
        {
          date: new Date().toISOString().split("T")[0],
          accountTitle: "Cash A/c",
          debit: null,
          credit: Number.parseInt(amount),
        },
      ]

      narration = `Being the purchase of ${item} for cash.`
    } else if (lowerPrompt.includes("sale") || lowerPrompt.includes("sold")) {
      // Extract amount using regex
      const amountMatch = promptText.match(/(\d+,)*\d+/)
      const amount = amountMatch ? amountMatch[0].replace(/,/g, "") : "75000"

      // Check if it's a cash sale
      const isCash = lowerPrompt.includes("cash")

      entries = [
        {
          date: new Date().toISOString().split("T")[0],
          accountTitle: isCash ? "Cash A/c" : "Accounts Receivable A/c",
          debit: Number.parseInt(amount),
          credit: null,
        },
        {
          date: new Date().toISOString().split("T")[0],
          accountTitle: "Sales A/c",
          debit: null,
          credit: Number.parseInt(amount),
        },
      ]

      narration = `Being the sale of goods ${isCash ? "for cash" : "on credit"}.`
    } else if (lowerPrompt.includes("rent") || lowerPrompt.includes("salary")) {
      // Extract amount using regex
      const amountMatch = promptText.match(/(\d+,)*\d+/)
      const amount = amountMatch ? amountMatch[0].replace(/,/g, "") : "15000"

      // Determine expense type
      const isRent = lowerPrompt.includes("rent")

      entries = [
        {
          date: new Date().toISOString().split("T")[0],
          accountTitle: isRent ? "Rent Expense A/c" : "Salary Expense A/c",
          debit: Number.parseInt(amount),
          credit: null,
        },
        {
          date: new Date().toISOString().split("T")[0],
          accountTitle: "Cash A/c",
          debit: null,
          credit: Number.parseInt(amount),
        },
      ]

      narration = `Being the payment of ${isRent ? "rent" : "salary"} for the period.`
    } else if (lowerPrompt.includes("loan")) {
      // Extract amount using regex
      const amountMatch = promptText.match(/(\d+,)*\d+/)
      const amount = amountMatch ? amountMatch[0].replace(/,/g, "") : "500000"

      // Check if taking or repaying loan
      const isTaking = !lowerPrompt.includes("repay") && !lowerPrompt.includes("pay")

      if (isTaking) {
        entries = [
          {
            date: new Date().toISOString().split("T")[0],
            accountTitle: "Cash A/c",
            debit: Number.parseInt(amount),
            credit: null,
          },
          {
            date: new Date().toISOString().split("T")[0],
            accountTitle: "Loan A/c",
            debit: null,
            credit: Number.parseInt(amount),
          },
        ]

        narration = "Being the loan received from the bank."
      } else {
        entries = [
          {
            date: new Date().toISOString().split("T")[0],
            accountTitle: "Loan A/c",
            debit: Number.parseInt(amount),
            credit: null,
          },
          {
            date: new Date().toISOString().split("T")[0],
            accountTitle: "Cash A/c",
            debit: null,
            credit: Number.parseInt(amount),
          },
        ]

        narration = "Being the repayment of loan to the bank."
      }
    } else {
      // Default case - generic transaction
      const amountMatch = promptText.match(/(\d+,)*\d+/)
      const amount = amountMatch ? amountMatch[0].replace(/,/g, "") : "10000"

      entries = [
        {
          date: new Date().toISOString().split("T")[0],
          accountTitle: "Miscellaneous Expense A/c",
          debit: Number.parseInt(amount),
          credit: null,
        },
        {
          date: new Date().toISOString().split("T")[0],
          accountTitle: "Cash A/c",
          debit: null,
          credit: Number.parseInt(amount),
        },
      ]

      narration = "Being the transaction as per description."
    }

    return { entries, narration }
  }

  const exportEntries = () => {
    // Create CSV content
    let csvContent = "Date,Account Title,Debit (₹),Credit (₹)\n"
    entries.forEach((entry) => {
      csvContent += `${entry.date},${entry.accountTitle},${entry.debit || ""},${entry.credit || ""}\n`
    })

    // Add narration at the end
    csvContent += `\nNarration: "${narration}"\n`

    // Create and download the file
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", "journal_entries.csv")
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const copyToClipboard = () => {
    // Format entries as text
    let text = "Date\tAccount Title\tDebit (₹)\tCredit (₹)\n"
    entries.forEach((entry) => {
      text += `${entry.date}\t${entry.accountTitle}\t${entry.debit ? entry.debit.toLocaleString("en-IN") : ""}\t${entry.credit ? entry.credit.toLocaleString("en-IN") : ""}\n`
    })

    // Add narration
    text += `\nNarration:\n"${narration}"\n`

    navigator.clipboard.writeText(text)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          Journal Entry Generator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Textarea
            placeholder="Describe the transaction in plain language. For example: 'Business started with cash Rs 2,00,000' or 'Purchased furniture for Rs 50,000 in cash'"
            className="min-h-[100px]"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          />
          <Button className="w-full" onClick={handleGenerateEntries} disabled={isLoading || !prompt.trim()}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Generate Journal Entries
              </>
            )}
          </Button>
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {entries.length > 0 && (
          <div className="space-y-4">
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Account Title</TableHead>
                    <TableHead className="text-right">Debit (₹)</TableHead>
                    <TableHead className="text-right">Credit (₹)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {entries.map((entry, index) => (
                    <TableRow key={index}>
                      <TableCell>{entry.date}</TableCell>
                      <TableCell>{entry.accountTitle}</TableCell>
                      <TableCell className="text-right">
                        {entry.debit ? entry.debit.toLocaleString("en-IN") : ""}
                      </TableCell>
                      <TableCell className="text-right">
                        {entry.credit ? entry.credit.toLocaleString("en-IN") : ""}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <div className="rounded-md border p-3">
              <div className="font-medium mb-1">Narration:</div>
              <p className="text-sm">{narration}</p>
            </div>

            <div className="flex gap-2 justify-end">
              <Button variant="outline" size="sm" onClick={copyToClipboard}>
                <Copy className="mr-2 h-4 w-4" />
                Copy
              </Button>
              <Button variant="outline" size="sm" onClick={exportEntries}>
                <Download className="mr-2 h-4 w-4" />
                Export CSV
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

