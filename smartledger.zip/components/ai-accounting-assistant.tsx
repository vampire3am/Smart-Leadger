"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2, Send, Bot, User, Paperclip, Sparkles, FileText, HelpCircle, Calculator, BookOpen } from "lucide-react"
import { cn } from "@/lib/utils"

// Define message type
type Message = {
  id: string
  role: "user" | "assistant" | "system"
  content: string
  timestamp: Date
  attachments?: string[]
  isLoading?: boolean
}

// Define suggested prompts
const SUGGESTED_PROMPTS = [
  "How do I record depreciation for a new asset?",
  "What's the correct journal entry for a loan payment?",
  "How should I categorize this transaction?",
  "Explain the difference between cash and accrual accounting",
  "How do I handle foreign currency transactions?",
  "What's the proper way to record prepaid expenses?",
  "How do I reconcile accounts payable?",
  "What tax implications should I consider for this transaction?",
  "How do I set up a chart of accounts for my business?",
  "What's the best way to track inventory in my accounting system?",
]

// Define accounting topics for help section
const ACCOUNTING_TOPICS = [
  {
    title: "Journal Entries",
    icon: <FileText className="h-4 w-4" />,
    description: "Learn how to create proper journal entries for various transactions",
  },
  {
    title: "Financial Statements",
    icon: <BookOpen className="h-4 w-4" />,
    description: "Understand balance sheets, income statements, and cash flow statements",
  },
  {
    title: "Tax Accounting",
    icon: <Calculator className="h-4 w-4" />,
    description: "Get help with tax-related accounting issues and compliance",
  },
  {
    title: "Reconciliation",
    icon: <HelpCircle className="h-4 w-4" />,
    description: "Learn how to reconcile accounts and resolve discrepancies",
  },
]

// Add a function to generate formatted journal entries based on user prompts
// Add this after the generateSimulatedResponse function:

const generateFormattedJournalEntry = (query) => {
  // Extract key information from the query
  const lowerQuery = query.toLowerCase()

  // Check for common accounting scenarios
  if (lowerQuery.includes("start") && lowerQuery.includes("business") && lowerQuery.includes("cash")) {
    // Extract amount using regex
    const amountMatch = query.match(/(\d+,)*\d+/)
    const amount = amountMatch ? amountMatch[0] : "2,00,000"

    return `Here's the journal entry for starting a business with cash:

Date\tAccount Title\tDebit (₹)\tCredit (₹)
[Date]\tCash A/c\t${amount}\t
[Date]\tCapital A/c\t\t${amount}

Narration:
"Being the capital introduced by the owner in the business."`
  } else if (lowerQuery.includes("purchase") && (lowerQuery.includes("cash") || lowerQuery.includes("paid"))) {
    // Extract amount using regex
    const amountMatch = query.match(/(\d+,)*\d+/)
    const amount = amountMatch ? amountMatch[0] : "50,000"

    // Extract item being purchased
    let item = "goods"
    if (lowerQuery.includes("furniture")) item = "furniture"
    else if (lowerQuery.includes("equipment")) item = "equipment"
    else if (lowerQuery.includes("inventory")) item = "inventory"

    return `Here's the journal entry for purchasing ${item} with cash:

Date\tAccount Title\tDebit (₹)\tCredit (₹)
[Date]\t${item.charAt(0).toUpperCase() + item.slice(1)} A/c\t${amount}\t
[Date]\tCash A/c\t\t${amount}

Narration:
"Being the purchase of ${item} for cash."`
  }

  // Default response for other accounting queries
  return `I can help you create properly formatted journal entries. Please provide details about the transaction, including:

1. The type of transaction (e.g., starting a business, purchase, sale)
2. The amount involved
3. The payment method (cash, credit, etc.)

For example, try asking:
- "Business started with cash Rs 2,00,000"
- "Purchased furniture for Rs 50,000 in cash"
- "Paid rent Rs 15,000 by cash"`
}

export function AIAccountingAssistant({ documentData = null }) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        "Hello! I'm your AI accounting assistant. I can help with journal entries, account classifications, tax implications, and any other accounting questions. How can I assist you today?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("chat")
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Generate a unique ID for messages
  const generateId = () => Math.random().toString(36).substring(2, 9)

  // Handle sending a message
  const handleSendMessage = async (content: string = input) => {
    if (!content.trim()) return

    // Add user message
    const userMessage: Message = {
      id: generateId(),
      role: "user",
      content,
      timestamp: new Date(),
    }

    // Add loading message from assistant
    const loadingMessage: Message = {
      id: generateId(),
      role: "assistant",
      content: "",
      timestamp: new Date(),
      isLoading: true,
    }

    setMessages((prev) => [...prev, userMessage, loadingMessage])
    setInput("")
    setIsLoading(true)

    try {
      // Simulate AI response with a delay
      setTimeout(() => {
        // Generate a response based on the input
        const response = generateSimulatedResponse(content, documentData)

        // Update the loading message with the response
        setMessages((prev) =>
          prev.map((msg) => (msg.isLoading ? { ...msg, content: response, isLoading: false } : msg)),
        )
        setIsLoading(false)
      }, 1500)
    } catch (error) {
      // Handle error
      setMessages((prev) =>
        prev.map((msg) =>
          msg.isLoading
            ? { ...msg, content: "Sorry, I encountered an error. Please try again.", isLoading: false }
            : msg,
        ),
      )
      console.error("Error generating response:", error)
      setIsLoading(false)
    }
  }

  // Generate a simulated AI response
  const generateSimulatedResponse = (query: string, docData: any) => {
    // Simple keyword-based response system
    const lowerQuery = query.toLowerCase()

    // Document-specific responses
    if (docData) {
      if (lowerQuery.includes("categorize") || lowerQuery.includes("classify")) {
        return `Based on the document from ${docData.vendor || "the vendor"}, this appears to be an office supplies purchase. I recommend categorizing it as "Office Supplies" expense. This would typically be recorded with a debit to Office Supplies and a credit to Accounts Payable or Cash, depending on how it was paid.`
      }

      if (lowerQuery.includes("journal entry") || lowerQuery.includes("record")) {
        return `For this ${docData.vendor || "vendor"} transaction of $${docData.amount?.toFixed(2) || "amount"}, I recommend the following journal entry:

1. Debit: Office Supplies $${docData.amount?.toFixed(2) || "amount"}
2. Credit: Accounts Payable $${docData.amount?.toFixed(2) || "amount"}

If tax was charged separately (${docData.taxAmount ? "$" + docData.taxAmount.toFixed(2) : "amount"}), you would also:
3. Debit: Sales Tax Expense $${docData.taxAmount?.toFixed(2) || "tax amount"}
4. Credit: Sales Tax Payable $${docData.taxAmount?.toFixed(2) || "tax amount"}

Description: Purchase of office supplies from ${docData.vendor || "vendor"} on ${docData.date || "date"}.`
      }

      if (lowerQuery.includes("tax")) {
        return `This purchase from ${docData.vendor || "the vendor"} includes $${docData.taxAmount?.toFixed(2) || "0.00"} in tax${docData.taxRate ? " at a rate of " + (docData.taxRate * 100).toFixed(2) + "%" : ""}. 

For tax accounting purposes:
1. The tax should be recorded separately from the main expense
2. Depending on your jurisdiction, this sales tax might be recoverable as an input tax credit
3. You should maintain proper documentation of this purchase for tax filing purposes

Would you like me to explain how to record this tax in your accounting system?`
      }
    }

    // Modify the generateSimulatedResponse function to check for journal entry requests
    // Find this line in the function:
    // return `Thank you for your question about "${query}". As an accounting assistant, I can provide guidance on this topic.

    // And add this condition before it:
    if (
      lowerQuery.includes("journal entry") ||
      lowerQuery.includes("record") ||
      (lowerQuery.includes("business") && lowerQuery.includes("start")) ||
      lowerQuery.includes("purchased") ||
      lowerQuery.includes("bought") ||
      lowerQuery.includes("paid") ||
      lowerQuery.includes("received")
    ) {
      return generateFormattedJournalEntry(query)
    }

    // General accounting responses
    if (lowerQuery.includes("depreciation")) {
      return `To record depreciation for a new asset, you would:

1. Determine the asset's useful life and salvage value
2. Choose a depreciation method (straight-line, declining balance, etc.)
3. Calculate the periodic depreciation expense
4. Record a journal entry:
   - Debit: Depreciation Expense $X
   - Credit: Accumulated Depreciation $X

For example, for a $10,000 asset with a 5-year useful life and no salvage value using straight-line depreciation:
   - Annual depreciation = $10,000 ÷ 5 = $2,000
   - Monthly entry: Debit Depreciation Expense $166.67, Credit Accumulated Depreciation $166.67`
    }

    if (lowerQuery.includes("accrual") && lowerQuery.includes("cash")) {
      return `Cash accounting and accrual accounting differ in when transactions are recorded:

**Cash Accounting:**
- Revenue is recorded when cash is received
- Expenses are recorded when cash is paid
- Simpler to maintain
- Used by small businesses and individuals
- Doesn't show complete financial picture (receivables/payables)

**Accrual Accounting:**
- Revenue is recorded when earned (regardless of when cash is received)
- Expenses are recorded when incurred (regardless of when cash is paid)
- More complex but more accurate representation of financial position
- Required for larger businesses and public companies
- Shows complete financial picture including receivables and payables

Would you like a specific example of how these methods differ?`
    }

    if (lowerQuery.includes("reconcile")) {
      return `To reconcile accounts payable:

1. Generate an accounts payable aging report from your accounting system
2. Compare this report with vendor statements
3. Identify discrepancies (missing invoices, payments not recorded, etc.)
4. Investigate each discrepancy:
   - Check if payments were recorded correctly
   - Verify invoice amounts match vendor records
   - Look for duplicate entries
5. Make necessary adjusting entries
6. Document the reconciliation process

Regular reconciliation helps prevent overpayment, missed payments, and ensures accurate financial reporting. Would you like more specific guidance on any of these steps?`
    }

    // Default response
    return `Thank you for your question about "${query}". As an accounting assistant, I can provide guidance on this topic.

To give you the most accurate answer, I'd need a bit more context. Could you provide additional details about:
1. The specific transaction or scenario you're dealing with
2. Your business type and industry
3. The accounting standards you follow (GAAP, IFRS, etc.)

This will help me provide more tailored accounting advice for your situation.`
  }

  // Handle file upload
  const handleFileUpload = () => {
    fileInputRef.current?.click()
  }

  // Handle file selection
  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    // In a real app, we would upload the file and process it
    // For now, just acknowledge the file
    setInput((prev) => `${prev} [Attached file: ${files[0].name}]`.trim())
  }

  // Handle suggested prompt click
  const handleSuggestedPrompt = (prompt: string) => {
    setInput(prompt)
  }

  // Format timestamp
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <Card className="flex flex-col h-[600px] w-full">
      <CardHeader className="px-4 py-3 border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bot className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg">AI Accounting Assistant</CardTitle>
            <Badge variant="outline" className="ml-2">
              GPT-Powered
            </Badge>
          </div>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-auto">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="chat">Chat</TabsTrigger>
              <TabsTrigger value="help">Help</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>

      <Tabs value={activeTab} className="flex-1 flex flex-col">
        <TabsContent value="chat" className="flex-1 flex flex-col p-0 m-0 data-[state=active]:flex-1">
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={cn("flex items-start gap-3 rounded-lg", message.role === "user" ? "flex-row-reverse" : "")}
                >
                  <Avatar
                    className={cn(
                      "flex h-8 w-8 shrink-0 select-none items-center justify-center rounded-full",
                      message.role === "user" ? "bg-primary" : "bg-muted",
                    )}
                  >
                    <AvatarFallback>
                      {message.role === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                    </AvatarFallback>
                  </Avatar>
                  <div
                    className={cn(
                      "flex flex-col gap-1 rounded-lg px-3 py-2 max-w-[80%]",
                      message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted",
                    )}
                  >
                    {message.isLoading ? (
                      <div className="flex items-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span>Thinking...</span>
                      </div>
                    ) : (
                      <div className="whitespace-pre-wrap">{message.content}</div>
                    )}
                    <div
                      className={cn(
                        "text-xs",
                        message.role === "user" ? "text-primary-foreground/70" : "text-muted-foreground",
                      )}
                    >
                      {formatTime(message.timestamp)}
                    </div>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          {!isLoading && (
            <div className="p-4">
              <div className="flex flex-wrap gap-2 mb-4">
                {SUGGESTED_PROMPTS.slice(0, 4).map((prompt, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="text-xs h-auto py-1.5"
                    onClick={() => handleSuggestedPrompt(prompt)}
                  >
                    <Sparkles className="h-3 w-3 mr-1" />
                    {prompt}
                  </Button>
                ))}
              </div>
            </div>
          )}

          <CardFooter className="p-4 pt-0">
            <form
              className="flex w-full items-center space-x-2"
              onSubmit={(e) => {
                e.preventDefault()
                handleSendMessage()
              }}
            >
              <Button type="button" size="icon" variant="outline" className="shrink-0" onClick={handleFileUpload}>
                <Paperclip className="h-4 w-4" />
                <span className="sr-only">Attach file</span>
              </Button>
              <input type="file" ref={fileInputRef} onChange={handleFileSelected} className="hidden" />
              <Textarea
                placeholder="Ask any accounting question..."
                className="min-h-10 flex-1 resize-none"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault()
                    handleSendMessage()
                  }
                }}
              />
              <Button type="submit" size="icon" className="shrink-0" disabled={isLoading || !input.trim()}>
                <Send className="h-4 w-4" />
                <span className="sr-only">Send</span>
              </Button>
            </form>
          </CardFooter>
        </TabsContent>

        <TabsContent value="help" className="flex-1 p-0 m-0 data-[state=active]:flex-1">
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-2">Accounting Topics</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {ACCOUNTING_TOPICS.map((topic, index) => (
                    <Card key={index} className="cursor-pointer hover:bg-muted/50 transition-colors">
                      <CardContent className="p-4 flex items-start gap-3">
                        <div className="mt-0.5 bg-primary/10 p-2 rounded-full">{topic.icon}</div>
                        <div>
                          <h4 className="font-medium">{topic.title}</h4>
                          <p className="text-sm text-muted-foreground">{topic.description}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">Suggested Questions</h3>
                <div className="space-y-2">
                  {SUGGESTED_PROMPTS.map((prompt, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="w-full justify-start text-left h-auto py-2"
                      onClick={() => {
                        handleSuggestedPrompt(prompt)
                        setActiveTab("chat")
                      }}
                    >
                      <Sparkles className="h-4 w-4 mr-2 shrink-0" />
                      <span>{prompt}</span>
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">What I Can Help With</h3>
                <Card>
                  <CardContent className="p-4 space-y-2">
                    <p className="text-sm">I can assist with a wide range of accounting tasks:</p>
                    <ul className="text-sm space-y-1">
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>Creating and explaining journal entries</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>Classifying accounts and transactions</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>Explaining accounting principles and standards</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>Providing guidance on financial reporting</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>Offering tax accounting advice</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>Helping with account reconciliation</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </Card>
  )
}

