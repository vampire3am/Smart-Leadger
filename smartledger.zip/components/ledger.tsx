"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, Filter, ChevronDown, ChevronUp, Search, Calendar, ArrowUpDown, FileText } from 'lucide-react'
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"

export function Ledger({ data }) {
  const [activeAccount, setActiveAccount] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [sortField, setSortField] = useState("date")
  const [sortDirection, setSortDirection] = useState("desc")
  const [dateRange, setDateRange] = useState({ from: null, to: null })
  const [selectedPeriod, setSelectedPeriod] = useState("current-month")
  
  // If no data is provided, show a placeholder message
  if (!data) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <LedgerIcon className="h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-medium mb-2">No Ledger Entries Yet</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Upload a document to automatically generate ledger entries
        </p>
      </div>
    )
  }

  // Generate sample ledger data based on the document data
  const generateLedgerData = () => {
    const today = new Date()
    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)
    const lastWeek = new Date(today)
    lastWeek.setDate(lastWeek.getDate() - 7)
    
    // Basic entries from the current document
    const currentEntries = [
      {
        id: 1,
        date: data.date,
        account: "Office Expenses",
        accountType: "expense",
        description: data.description,
        reference: data.receiptNumber || "R-12345",
        debit: data.amount,
        credit: 0,
        balance: data.amount,
        document: "Receipt"
      },
      {
        id: 2,
        date: data.date,
        account: "Accounts Payable",
        accountType: "liability",
        description: `Payment to ${data.vendor}`,
        reference: data.receiptNumber || "R-12345",
        debit: 0,
        credit: data.amount,
        balance: -data.amount,
        document: "Receipt"
      }
    ]
    
    // Add tax entries if applicable
    const taxEntries = data.taxAmount && data.taxAmount > 0 ? [
      {
        id: 3,
        date: data.date,
        account: "Sales Tax Payable",
        accountType: "liability",
        description: `Tax on ${data.vendor} purchase`,
        reference: data.receiptNumber || "R-12345",
        debit: 0,
        credit: data.taxAmount,
        balance: -data.taxAmount,
        document: "Receipt"
      },
      {
        id: 4,
        date: data.date,
        account: "Office Expenses",
        accountType: "expense",
        description: `Tax on ${data.description}`,
        reference: data.receiptNumber || "R-12345",
        debit: data.taxAmount,
        credit: 0,
        balance: data.taxAmount,
        document: "Receipt"
      }
    ] : []
    
    // Sample historical data
    const historicalEntries = [
      {
        id: 5,
        date: formatDate(yesterday),
        account: "Cash",
        accountType: "asset",
        description: "Office rent payment",
        reference: "CHK-1001",
        debit: 0,
        credit: 1500,
        balance: -1500,
        document: "Check"
      },
      {
        id: 6,
        date: formatDate(yesterday),
        account: "Rent Expense",
        accountType: "expense",
        description: "Monthly office rent",
        reference: "CHK-1001",
        debit: 1500,
        credit: 0,
        balance: 1500,
        document: "Check"
      },
      {
        id: 7,
        date: formatDate(lastWeek),
        account: "Accounts Receivable",
        accountType: "asset",
        description: "Client invoice payment",
        reference: "INV-2023",
        debit: 2500,
        credit: 0,
        balance: 2500,
        document: "Invoice"
      },
      {
        id: 8,
        date: formatDate(lastWeek),
        account: "Revenue",
        accountType: "revenue",
        description: "Consulting services",
        reference: "INV-2023",
        debit: 0,
        credit: 2500,
        balance: -2500,
        document: "Invoice"
      }
    ]
    
    return [...currentEntries, ...taxEntries, ...historicalEntries]
  }

  const ledgerData = useMemo(() => generateLedgerData(), [data])
  
  // Format date helper
  function formatDate(date) {
    if (!date) return ""
    if (typeof date === 'string') return date
    return date.toISOString().split('T')[0]
  }

  // Filter ledger data based on active account, search query, and date range
  const filteredLedgerData = useMemo(() => {
    return ledgerData.filter(entry => {
      // Filter by account type
      if (activeAccount !== "all" && entry.accountType !== activeAccount) {
        return false
      }
      
      // Filter by search query
      if (searchQuery) {
        const query = searchQuery.toLowerCase()
        return (
          entry.account.toLowerCase().includes(query) ||
          entry.description.toLowerCase().includes(query) ||
          entry.reference.toLowerCase().includes(query)
        )
      }
      
      // Filter by date range
      if (dateRange.from && dateRange.to) {
        const entryDate = new Date(entry.date)
        return entryDate >= dateRange.from && entryDate <= dateRange.to
      }
      
      return true
    })
  }, [ledgerData, activeAccount, searchQuery, dateRange])
  
  // Sort filtered data
  const sortedLedgerData = useMemo(() => {
    return [...filteredLedgerData].sort((a, b) => {
      if (sortField === "date") {
        const dateA = new Date(a.date)
        const dateB = new Date(b.date)
        return sortDirection === "asc" ? dateA - dateB : dateB - dateA
      }
      
      if (sortField === "amount") {
        const amountA = Math.max(a.debit, a.credit)
        const amountB = Math.max(b.debit, b.credit)
        return sortDirection === "asc" ? amountA - amountB : amountB - amountA
      }
      
      // Sort by account name
      if (sortField === "account") {
        return sortDirection === "asc" 
          ? a.account.localeCompare(b.account)
          : b.account.localeCompare(a.account)
      }
      
      return 0
    })
  }, [filteredLedgerData, sortField, sortDirection])
  
  // Handle sort
  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("asc")
    }
  }
  
  // Calculate account summaries
  const accountSummaries = useMemo(() => {
    const summaries = {
      assets: 0,
      liabilities: 0,
      expenses: 0,
      revenue: 0
    }
    
    ledgerData.forEach(entry => {
      if (entry.accountType === "asset") {
        summaries.assets += entry.debit - entry.credit
      } else if (entry.accountType === "liability") {
        summaries.liabilities += entry.credit - entry.debit
      } else if (entry.accountType === "expense") {
        summaries.expenses += entry.debit - entry.credit
      } else if (entry.accountType === "revenue") {
        summaries.revenue += entry.credit - entry.debit
      }
    })
    
    return summaries
  }, [ledgerData])
  
  // Handle period selection
  const handlePeriodChange = (period) => {
    setSelectedPeriod(period)
    
    const today = new Date()
    let from = null
    let to = new Date(today)
    
    switch (period) {
      case "current-month":
        from = new Date(today.getFullYear(), today.getMonth(), 1)
        break
      case "previous-month":
        from = new Date(today.getFullYear(), today.getMonth() - 1, 1)
        to = new Date(today.getFullYear(), today.getMonth(), 0)
        break
      case "quarter":
        const quarter = Math.floor(today.getMonth() / 3)
        from = new Date(today.getFullYear(), quarter * 3, 1)
        break
      case "year":
        from = new Date(today.getFullYear(), 0, 1)
        break
      case "custom":
        // Don't set date range for custom - will be handled by calendar
        return
      default:
        break
    }
    
    setDateRange({ from, to })
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-2">
          <Select 
            defaultValue={selectedPeriod} 
            onValueChange={handlePeriodChange}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current-month">Current Month</SelectItem>
              <SelectItem value="previous-month">Previous Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
              <SelectItem value="year">This Year</SelectItem>
              <SelectItem value="custom">Custom Range</SelectItem>
            </SelectContent>
          </Select>
          
          {selectedPeriod === "custom" && (
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="h-9 border-dashed">
                  <Calendar className="mr-2 h-4 w-4" />
                  {dateRange.from ? (
                    dateRange.to ? (
                      <>
                        {formatDate(dateRange.from)} - {formatDate(dateRange.to)}
                      </>
                    ) : (
                      formatDate(dateRange.from)
                    )
                  ) : (
                    <span>Pick a date range</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  initialFocus
                  mode="range"
                  defaultMonth={dateRange.from}
                  selected={dateRange}
                  onSelect={setDateRange}
                  numberOfMonths={2}
                />
              </PopoverContent>
            </Popover>
          )}
          
          <Button variant="outline" size="icon" className="h-9 w-9">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative w-full sm:w-auto">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search ledger..." 
              className="pl-8 w-full sm:w-[250px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button variant="outline" size="icon" className="h-9 w-9">
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <Tabs value={activeAccount} onValueChange={setActiveAccount}>
        <TabsList className="grid grid-cols-5 mb-4">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="asset">Assets</TabsTrigger>
          <TabsTrigger value="liability">Liabilities</TabsTrigger>
          <TabsTrigger value="expense">Expenses</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
        </TabsList>
        
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[100px] cursor-pointer" onClick={() => handleSort("date")}>
                    <div className="flex items-center">
                      Date
                      {sortField === "date" && (
                        sortDirection === "asc" ? <ChevronUp className="ml-1 h-4 w-4" /> : <ChevronDown className="ml-1 h-4 w-4" />
                      )}
                      {sortField !== "date" && <ArrowUpDown className="ml-1 h-4 w-4 opacity-50" />}
                    </div>
                  </TableHead>
                  <TableHead className="cursor-pointer" onClick={() => handleSort("account")}>
                    <div className="flex items-center">
                      Account
                      {sortField === "account" && (
                        sortDirection === "asc" ? <ChevronUp className="ml-1 h-4 w-4" /> : <ChevronDown className="ml-1 h-4 w-4" />
                      )}
                      {sortField !== "account" && <ArrowUpDown className="ml-1 h-4 w-4 opacity-50" />}
                    </div>
                  </TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Reference</TableHead>
                  <TableHead className="text-right">Debit</TableHead>
                  <TableHead className="text-right">Credit</TableHead>
                  <TableHead className="text-right cursor-pointer" onClick={() => handleSort("amount")}>
                    <div className="flex items-center justify-end">
                      Balance
                      {sortField === "amount" && (
                        sortDirection === "asc" ? <ChevronUp className="ml-1 h-4 w-4" /> : <ChevronDown className="ml-1 h-4 w-4" />
                      )}
                      {sortField !== "amount" && <ArrowUpDown className="ml-1 h-4 w-4 opacity-50" />}
                    </div>
                  </TableHead>
                  <TableHead className="w-[100px]">Document</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedLedgerData.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-6 text-muted-foreground">
                      No ledger entries match your filters
                    </TableCell>
                  </TableRow>
                ) : (
                  sortedLedgerData.map((entry) => (
                    <TableRow key={entry.id}>
                      <TableCell>{entry.date}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {entry.account}
                          <Badge variant="outline" className="text-xs capitalize">
                            {entry.accountType}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell>{entry.description}</TableCell>
                      <TableCell>{entry.reference}</TableCell>
                      <TableCell className="text-right">{entry.debit > 0 ? `$${entry.debit.toFixed(2)}` : "-"}</TableCell>
                      <TableCell className="text-right">{entry.credit > 0 ? `$${entry.credit.toFixed(2)}` : "-"}</TableCell>
                      <TableCell className={`text-right font-medium ${entry.balance < 0 ? "text-red-500" : ""}`}>
                        {entry.balance < 0 ? "-" : ""}${Math.abs(entry.balance).toFixed(2)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          <span className="text-xs">{entry.document}</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </Tabs>
      
      <div className="mt-4 grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-muted/50">
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground mb-1">Total Assets</div>
            <div className="text-xl font-semibold">${Math.max(0, accountSummaries.assets).toFixed(2)}</div>
            <div className="text-xs text-muted-foreground mt-1">
              {accountSummaries.assets >= 0 ? "+" : ""}{accountSummaries.assets.toFixed(2)} net change
            </div>
          </CardContent>
        </Card>
        <Card className="bg-muted/50">
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground mb-1">Total Liabilities</div>
            <div className="text-xl font-semibold">${Math.max(0, accountSummaries.liabilities).toFixed(2)}</div>
            <div className="text-xs text-muted-foreground mt-1">
              {accountSummaries.liabilities >= 0 ? "+" : ""}{accountSummaries.liabilities.toFixed(2)} net change
            </div>
          </CardContent>
        </Card>
        <Card className="bg-muted/50">
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground mb-1">Total Expenses</div>
            <div className="text-xl font-semibold">${Math.max(0, accountSummaries.expenses).toFixed(2)}</div>
            <div className="text-xs text-muted-foreground mt-1">
              {accountSummaries.expenses >= 0 ? "+" : ""}{accountSummaries.expenses.toFixed(2)} net change
            </div>
          </CardContent>
        </Card>
        <Card className="bg-muted/50">
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground mb-1">Total Revenue</div>
            <div className="text-xl font-semibold">${Math.max(0, accountSummaries.revenue).toFixed(2)}</div>
            <div className="text-xs text-muted-foreground mt-1">
              {accountSummaries.revenue >= 0 ? "+" : ""}{accountSummaries.revenue.toFixed(2)} net change
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function LedgerIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M4 2v20a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8.7a1 1 0 0 0-.3-.7l-5-5a1 1 0 0 0-.7-.3H6a2 2 0 0 0-2 2Z" />
      <path d="M14 2v4a2 2 0 0 0 2 2h4" />
      <path d="M8 10h8" />
      <path d="M8 14h8" />
      <path d="M8 18h8" />
    </svg>
  )
}

