"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Receipt,
  Upload,
  FileText,
  BarChart3,
  Settings,
  ArrowLeft,
  HelpCircle,
  Bell,
  User,
  CreditCard,
  DollarSign,
  Sparkles,
  MessageSquare,
  X,
} from "lucide-react"
import { ImageUploader } from "@/components/image-uploader"
import { JournalEntries } from "@/components/journal-entries"
import { Ledger } from "@/components/ledger"
import { AIAccountingAssistant } from "@/components/ai-accounting-assistant"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { PromptEntryGenerator } from "@/components/prompt-entry-generator"

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("upload")
  const [hasUploadedImage, setHasUploadedImage] = useState(false)
  const [extractedData, setExtractedData] = useState(null)
  const [processingStats, setProcessingStats] = useState({
    documentsProcessed: 0,
    entriesCreated: 0,
    accuracy: 0,
  })
  const [showAiAssistant, setShowAiAssistant] = useState(false)

  const handleImageProcessed = (data) => {
    setExtractedData(data)
    setHasUploadedImage(true)
    setActiveTab("entries")

    // Update processing stats
    setProcessingStats({
      documentsProcessed: processingStats.documentsProcessed + 1,
      entriesCreated: processingStats.entriesCreated + (data.lineItems?.length || 1),
      accuracy: data.confidence ? Math.round(data.confidence * 100) : 85,
    })
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2">
          <ArrowLeft className="h-5 w-5" />
          <span className="sr-only md:not-sr-only md:inline">Back</span>
        </Link>
        <div className="flex items-center gap-2">
          <Receipt className="h-6 w-6 text-primary" />
          <h1 className="text-lg font-semibold">SmartLedger Dashboard</h1>
          <Badge variant="outline" className="ml-2 text-xs">
            AI Enhanced
          </Badge>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="hidden md:flex"
            onClick={() => setShowAiAssistant(!showAiAssistant)}
          >
            <Sparkles className="mr-2 h-4 w-4" />
            AI Assistant
          </Button>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" className="rounded-full">
                  <HelpCircle className="h-5 w-5" />
                  <span className="sr-only">Help</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="max-w-xs">Need help? Click here for tutorials and support</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" className="rounded-full">
                  <Bell className="h-5 w-5" />
                  <span className="sr-only">Notifications</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>You have no new notifications</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon" className="rounded-full">
                <User className="h-5 w-5" />
                <span className="sr-only">User menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <HelpCircle className="mr-2 h-4 w-4" />
                <span>Help & Support</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <ArrowLeft className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Documents Processed</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{hasUploadedImage ? processingStats.documentsProcessed : "0"}</div>
              <p className="text-xs text-muted-foreground">
                {hasUploadedImage ? "+1 from last session" : "+0 from last session"}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Journal Entries</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{hasUploadedImage ? processingStats.entriesCreated : "0"}</div>
              <p className="text-xs text-muted-foreground">
                {hasUploadedImage ? `+${processingStats.entriesCreated} from last session` : "+0 from last session"}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">AI Accuracy</CardTitle>
              <Sparkles className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <div className="text-2xl font-bold">{hasUploadedImage ? `${processingStats.accuracy}%` : "0%"}</div>
                {hasUploadedImage && (
                  <Badge variant={processingStats.accuracy > 85 ? "default" : "outline"} className="text-xs">
                    {processingStats.accuracy > 85 ? "High" : "Medium"}
                  </Badge>
                )}
              </div>
              <div className="mt-2">
                <Progress value={hasUploadedImage ? processingStats.accuracy : 0} className="h-2" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ${hasUploadedImage ? extractedData?.total || extractedData?.amount || "0.00" : "0.00"}
              </div>
              <p className="text-xs text-muted-foreground">
                {hasUploadedImage
                  ? `+$${extractedData?.total || extractedData?.amount} from last session`
                  : "+$0.00 from last session"}
              </p>
            </CardContent>
          </Card>
        </div>

        {showAiAssistant && (
          <Card className="mb-4">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-primary" />
                  <CardTitle>AI Accounting Assistant</CardTitle>
                </div>
                <Button variant="ghost" size="icon" onClick={() => setShowAiAssistant(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <CardDescription>Ask any accounting question or get help with your financial documents</CardDescription>
            </CardHeader>
            <CardContent>
              <AIAccountingAssistant documentData={extractedData} />
            </CardContent>
          </Card>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-4 md:w-auto">
            <TabsTrigger value="upload" className="flex items-center gap-2">
              <Upload className="h-4 w-4" />
              <span className="hidden sm:inline">Upload Document</span>
              <span className="sm:hidden">Upload</span>
            </TabsTrigger>
            <TabsTrigger value="generate" className="flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              <span className="hidden sm:inline">Generate Entries</span>
              <span className="sm:hidden">Generate</span>
            </TabsTrigger>
            <TabsTrigger value="entries" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Journal Entries</span>
              <span className="sm:hidden">Entries</span>
            </TabsTrigger>
            <TabsTrigger value="ledger" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">General Ledger</span>
              <span className="sm:hidden">Ledger</span>
            </TabsTrigger>
          </TabsList>
          <TabsContent value="upload" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Upload Financial Document</CardTitle>
                <CardDescription>
                  Upload a receipt, invoice, or any financial document to automatically extract data and create journal
                  entries
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ImageUploader onImageProcessed={handleImageProcessed} />
              </CardContent>
            </Card>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">AI-Powered Processing</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-start gap-2">
                      <Sparkles className="h-4 w-4 text-primary mt-1" />
                      <div>
                        <span className="font-medium">Enhanced Accuracy</span>
                        <p className="text-muted-foreground">
                          AI improves data extraction accuracy by up to 35% compared to traditional OCR
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Sparkles className="h-4 w-4 text-primary mt-1" />
                      <div>
                        <span className="font-medium">Smart Classification</span>
                        <p className="text-muted-foreground">
                          Automatically categorizes transactions based on accounting principles
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Sparkles className="h-4 w-4 text-primary mt-1" />
                      <div>
                        <span className="font-medium">Accounting Insights</span>
                        <p className="text-muted-foreground">
                          Provides recommendations for proper accounting treatment
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Supported Document Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2">
                      <Receipt className="h-4 w-4 text-primary" />
                      <span>Receipts</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-primary" />
                      <span>Invoices</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CreditCard className="h-4 w-4 text-primary" />
                      <span>Credit Card Statements</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-primary" />
                      <span>Bank Statements</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-primary" />
                      <span>Purchase Orders</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="md:col-span-2 lg:col-span-1">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Ask the AI Assistant</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      Our AI assistant can help with any accounting questions:
                    </p>
                    <div className="grid grid-cols-1 gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="justify-start text-left h-auto py-2"
                        onClick={() => setShowAiAssistant(true)}
                      >
                        <MessageSquare className="mr-2 h-4 w-4" />
                        <span>How should I categorize this expense?</span>
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="justify-start text-left h-auto py-2"
                        onClick={() => setShowAiAssistant(true)}
                      >
                        <MessageSquare className="mr-2 h-4 w-4" />
                        <span>What's the proper journal entry for this?</span>
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="justify-start text-left h-auto py-2"
                        onClick={() => setShowAiAssistant(true)}
                      >
                        <MessageSquare className="mr-2 h-4 w-4" />
                        <span>Are there tax implications I should know?</span>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="generate" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Generate Journal Entries</CardTitle>
                <CardDescription>
                  Describe a transaction in plain language and get properly formatted journal entries
                </CardDescription>
              </CardHeader>
              <CardContent>
                <PromptEntryGenerator />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="entries" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Journal Entries</CardTitle>
                <CardDescription>
                  View and manage automatically generated journal entries from your documents
                </CardDescription>
              </CardHeader>
              <CardContent>
                <JournalEntries data={extractedData} />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="ledger" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>General Ledger</CardTitle>
                <CardDescription>View your complete general ledger with all accounts and transactions</CardDescription>
              </CardHeader>
              <CardContent>
                <Ledger data={extractedData} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

